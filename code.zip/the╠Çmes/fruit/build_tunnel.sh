#!/usr/bin/env bash

echo "Encapsulation Vue -> Drupal STORE LOCATOR"

DRUPAL_URL=''

cd app

echo "Begining - Generate Drupal YML File from VueJS build"

# Nom de la bibliothèque
nom_bibliotheque="fruit_spa"

# Création du fichier libraries.yml
echo "$nom_bibliotheque:" > libraries.yml
echo "  version: 1.x" >> libraries.yml
echo "  css:" >> libraries.yml
echo "    theme:" >> libraries.yml

# Parcours des fichiers CSS et ajout dans libraries.yml
for css in "./dist/assets"/*.css; do
  echo "      templates/vue-build/$(basename $css): {}" >> libraries.yml
done

# Ajout du fichier load-module.js
echo "  js:" >> libraries.yml

# Parcours des fichiers JS et ajout dans le fichier de load des modules
for js in "./dist/assets"/*.js; do
  echo "      /themes/custom/fruit/templates/vue-build/$(basename $js): { type: external, attributes: { type: module }}" >> libraries.yml
done

echo "Le fichier libraries.yml a été généré avec succès!"

echo "Finished - Generate Drupal YML File from VueJS build"

cd ..

echo "Copy VueJS Build into templates folder"
rm templates/vue-build/*

cp  app/dist/assets/* templates/vue-build

sed -i -- 's|css/|themes/custom/fruit/templates/vue-build/|g' templates/vue-build/*.js
sed -i -- 's|css/|themes/custom/fruit/templates/vue-build/|g' templates/vue-build/*.css
sed -i -- 's|js/|themes/custom/fruit/templates/vue-build/|g' templates/vue-build/*.js
sed -i -- 's|js/|themes/custom/fruit/templates/vue-build/|g' templates/vue-build/*.css
sed -i -- 's|assets/|themes/custom/fruit/templates/vue-build/|g' templates/vue-build/*.js
sed -i -- 's|assets/|themes/custom/fruit/templates/vue-build/|g' templates/vue-build/*.css

echo "Replace fruit.libraries.yml with newer one"
rm fruit.libraries.yml
cp app/libraries.yml fruit.libraries.yml

cd ../../../..

vendor/bin/drush cr
