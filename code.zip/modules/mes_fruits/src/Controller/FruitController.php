<?php

namespace Drupal\mes_fruits\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\mes_fruits\Service\FruitServices;
use Symfony\Component\HttpFoundation\Response;

class FruitController extends ControllerBase {

  protected FruitServices $fruitServices;

  /**
   * FruitController constructor.
   *
   * @param \Drupal\mes_fruits\Service\FruitServices $fruitServices
   */
  public function __construct(FruitServices $fruitServices) {
    $this->fruitServices = $fruitServices;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): self {
    return new static(
      $container->get('mes_fruits.fruit_services')
    );
  }

  /**
   * Get fruits based on the taxonomy term name.
   *
   * @param string $nomDuFruit
   *
   * @return \Symfony\Component\HttpFoundation\Response
   */
  public function getFruits(string $nomDuFruit): Response {
    $nodes = $this->fruitServices->getFruitsByTaxonomyTerm($nomDuFruit);

    $retour = [];
    foreach ($nodes as $node) {
      $retour[] = $node->toArray();
    }

    $data = json_encode(
			['results' => $retour],
			 JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
		);
    return new Response($data, 200, ['Content-Type' => 'application/json']);
  }

  /**
   * View my page with my fruits.
   *
   * @return array
   *   My page.
   */
  public function view_page(): array {
    $nodes = $this->fruitServices->getAllFruits();

    $retour = [];
    foreach ($nodes as $node) {
      $retour[] = $node->title->value;
    }

    return [
      '#theme' => 'mes_fruits',  // Correspond au hook_theme défini dans le .module
      '#fruits' => $retour,
    ];
  }

}
