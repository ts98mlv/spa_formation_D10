<?php
namespace Drupal\mes_fruits\Service;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\node\NodeInterface;

class FruitServices {

  protected $nodeStorage;
  protected $taxonomyTermStorage;

  public function __construct(EntityTypeManagerInterface $entity_type_manager) {
    $this->nodeStorage = $entity_type_manager->getStorage('node');
    $this->taxonomyTermStorage = $entity_type_manager->getStorage('taxonomy_term');
  }

  /**
   * @param string $term
   * @return array
   */
  public function getFruitsByTaxonomyTerm(string $term): array {
    $tid = $this->getTidByName($term);

    if ($tid) {
      $query = $this->nodeStorage->getQuery()
        ->condition('type', 'node_fruit')
        ->condition('field_mes_fruits', $tid)
        ->accessCheck(TRUE)
        ->execute();

      $nodes = $this->nodeStorage->loadMultiple($query);

      return $nodes;
    }

    return [];
  }

  /**
   * @param string $term
   * @return int|null
   */
  private function getTidByName(string $term): ?int {
    $query = $this->taxonomyTermStorage->getQuery()
      ->condition('vid', 'fruits')
      ->condition('name', $term)
      ->accessCheck(TRUE)
      ->execute();

    $term_ids = array_keys($query);

    return !empty($term_ids) ? reset($term_ids) : NULL;
  }


  /**
   * @return array
   */
  public function getAllFruits(): array {
    $query = $this->nodeStorage->getQuery()
      ->condition('type', 'node_fruit')
      ->condition('status', 1)
      ->accessCheck(TRUE)
      ->execute();

    $retour = [];

    foreach ($query as $nid) {
      $retour[] = $this->nodeStorage->load($nid);
    }

    return $retour;
  }


}
