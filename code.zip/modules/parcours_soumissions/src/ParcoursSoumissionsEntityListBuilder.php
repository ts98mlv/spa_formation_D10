<?php

namespace Drupal\parcours_soumissions;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;

/**
 * Class ParcoursSoumissionsEntityListBuilder.
 */
class ParcoursSoumissionsEntityListBuilder extends EntityListBuilder {

  /**
   * Construit les en-têtes de la table de liste.
   */
  public function buildHeader(): array {
    $header['id'] = $this->t('ID');
    $header['uuid'] = $this->t('UUID');
    $header['name'] = $this->t('Nom');
    $header['firstname'] = $this->t('Prénom');
    $header['creation_date'] = $this->t('Date de Création');
    $header['updated_date'] = $this->t('Date de Modification');

    return $header + parent::buildHeader();
  }

  /**
   * Construit une ligne de la table de liste.
   */
  public function buildRow(EntityInterface $entity): array {
    /* @var $entity \Drupal\parcours_soumissions\Entity\ParcoursSoumissionsEntity */
    $row['id'] = $entity->id();
    $row['uuid'] = $entity->uuid();
    $row['nom'] = $entity->get('name')->value;
    $row['prenom'] = $entity->get('firstname')->value;
    $row['date_creation'] = $entity->get('creation_date')->value;
    $row['date_modification'] = $entity->get('updated_date')->value;

    return $row + parent::buildRow($entity);
  }

}
