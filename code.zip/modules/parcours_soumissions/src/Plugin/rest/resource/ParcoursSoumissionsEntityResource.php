<?php

namespace Drupal\parcours_soumissions\Plugin\rest\resource;

use Drupal\Component\Datetime\Time;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Entity\EntityStorageException;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManager;
use Drupal\rest\Annotation\RestResource;
use Drupal\rest\ModifiedResourceResponse;
use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ResourceResponse;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Route;

/**
 * Gère les soumissions de parcours.
 *
 * @RestResource (
 *   id = "parcours_soumissions_entity_resource",
 *   label = @Translation("Gère les soumissions de parcours"),
 *   uri_paths = {
 *     "canonical" = "/api/parcours-soumissions/{uuid}",
 *     "create" = "/api/parcours-soumissions"
 *   }
 * )
 *
 */
class ParcoursSoumissionsEntityResource extends ResourceBase {

  /**
   * The entity parcours_web_submission storage.
   *
   * @var \Drupal\Core\Entity\EntityStorageInterface
   */
  protected EntityStorageInterface $entityStorage;

  protected Time $date;

  /**
   * {@inheritdoc}
   */
  public function __construct(
    array $configuration,
    string $plugin_id,
    array $plugin_definition,
    array $serializer_formats,
    LoggerInterface $logger,
    EntityTypeManager $manager,
    Time $dateTime
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $serializer_formats, $logger);
    $this->entityStorage = $manager->getStorage('parcours_soumissions_entity') ?? NULL;
    $this->date = $dateTime;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): self {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->getParameter('serializer.formats'),
      $container->get('logger.factory')->get('rest'),
      $container->get('entity_type.manager'),
      $container->get('datetime.time')
    );
  }

  /**
   * Responds to POST requests and saves the new record.
   *
   * @param array $data
   *   Data to write into the database.
   *
   * @return \Symfony\Component\HttpFoundation\Response
   *   The HTTP response object.
   */
  public function post(array $data): Response {
    $currentDateTime = DrupalDateTime::createFromTimestamp(time());
    try {
      $record = $this->entityStorage->create();
      $record->set('name', $data['name'] ?? 'inconnu');
      $record->set('firstname', $data['firstname'] ?? 'inconnu');
      $record->set('parcours_type', $data['parcours_type'] ?? 'inconnu');
      $record->set('saved_data',
        \json_encode(
          $data['saved_data'] ?? [],
          JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
        )
      );
      $record->save();

      // Return the newly created record in the response body.
      return new ModifiedResourceResponse($this->entityStorage->load($record->id())->toArray(), 201);
    }
    catch (EntityStorageException $e) {
      return new Response('Internal server error', 500);
    }
  }

  /**
   * Responds to GET requests.
   *
   * @param string $uuid
   *   The UUID of the record.
   *
   * @return \Symfony\Component\HttpFoundation\Response.
   *   The response containing the record.
   */
  public function get(string $uuid): Response {
    $nid = $this->entityStorage->getQuery()->condition('uuid', $uuid)->execute();

    $nid = \reset($nid);

    $record = $this->entityStorage->load($nid) ?? null;

    if (empty($record)) {
      $response = new Response('Ressource non trouvée', 404);
      $response->headers->set('Content-Type', 'text/plain');
      return $response;
    }
    return new Response(json_encode(
      $record->get('saved_data')->first()->value ?? [],
      JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
    ), 200);
  }

  /**
   * Responds to PATCH requests.
   *
   * @param string $uuid
   *   The UUID of the record.
   * @param array $data
   *   Data to write into the storage.
   *
   * @return \Symfony\Component\HttpFoundation\Response
   *   The HTTP response object.
   */
  public function patch(string $uuid, array $data): Response {
    $nid = $this->entityStorage->getQuery()->condition('uuid', $uuid)->execute();

    $nid = \reset($nid);

    $record = $this->entityStorage->load($nid) ?? null;
    
    $currentDateTime = DrupalDateTime::createFromTimestamp(time());

    if (empty($record)) {
      $response = new Response('Ressource non trouvée', 404);
      $response->headers->set('Content-Type', 'text/plain');
      return $response;
    }
    if (empty($data)) {
      $response = new Response('Requête mal formatée', 400);
      $response->headers->set('Content-Type', 'text/plain');
      return $response;
    }

    try {
      if (!empty($data['name'])) {
        $record->set('name', $data['name']);
      }
      if (!empty($data['firstname'])) {
        $record->set('firstname', $data['firstname']);
      }
      if (!empty($data['saved_data'])) {
        $record->set('saved_date',
          \json_encode(
            $data['saved_data'],
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
        );
      }
      $record->save();

      return new ModifiedResourceResponse($this->entityStorage->load($nid)->toArray(), 200);
    } catch (\Exception $e) {
      return new Response(json_encode([
        'message' => 'Le serveur rencontre une erreur',
        'trace' => $e->getTrace(),
        'code' => 500,
      ]), 500);
    }
  }

  /**
   * Responds to DELETE requests.
   *
   * @param string $uuid
   *   The UUID of the record.
   *
   * @return \Symfony\Component\HttpFoundation\Response
   *   The HTTP response object.
   */
  public function delete(string $uuid): Response {
    $nid = $this->entityStorage->getQuery()->condition('uuid', $uuid)->execute();

    $nid = \reset($nid);

    $record = $this->entityStorage->load($nid) ?? null;

    if (empty($record)) {
      $response = new Response('Ressource non trouvée', 404);
      $response->headers->set('Content-Type', 'text/plain');
      return $response;
    }

    try {
      $record->delete();
      return new Response("Ressource supprimée", 204);
    } catch (\Exception $e) {
      return new Response(json_encode([
        'message' => 'Le serveur rencontre une erreur',
        'trace' => $e->getTrace(),
        'code' => 500,
      ]), 500);
    }
  }


}
