<?php

namespace Drupal\parcours_soumissions\Entity;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Fournit une interface pour définir les entités de soumission de parcours.
 *
 * Nous avons défini des méthodes pour les opérations CRUD nécessaires.
 *
 */
interface ParcoursSoumissionsEntityInterface extends ContentEntityInterface, EntityOwnerInterface {

  /**
   * Obtient le nom de l'entité de soumission de parcours.
   *
   * @return string
   *   Le nom de l'entité de soumission de parcours.
   */
  public function getName(): string;

  /**
   * Définit le nom de l'entité de soumission de parcours.
   *
   * @param string $name
   *   Le nom de l'entité de soumission de parcours.
   */
  public function setName(string $name): void;

  /**
   * Obtient le nom de l'entité de soumission de parcours.
   *
   * @return string
   *   Le nom de l'entité de soumission de parcours.
   */
  public function getFirstName(): string;

  /**
   * Définit le prénom de l'entité de soumission de parcours.
   *
   * @param string $firstName
   *   Le prénom de l'entité de soumission de parcours.
   */
  public function setFirstName(string $firstName): void;

  /**
   * Obtient la date de création de la soumission.
   *
   * @return string
   *   La date de création.
   */
  public function getCreationDate(): string;

  /**
   * Obtient la date de modification de la soumission.
   *
   * @return string
   *   La date de modification.
   */
  public function getUpdatedDate(): string;
  
  /**
   * Retourne les données sauvegardées.
   *
   * @return string
   *   Les données sauvegardées.
   */
  public function getSavedData(): string;

  /**
   * Sauvegarde les données de la soumission.
   *
   * @param string $data
   *   Les données à sauvegarder
   */
  public function setSavedData(string $data): void;
}
