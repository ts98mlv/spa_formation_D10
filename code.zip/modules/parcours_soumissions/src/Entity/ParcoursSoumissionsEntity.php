<?php

namespace Drupal\parcours_soumissions\Entity;

use Drupal\Core\Entity\Annotation\ContentEntityType;
use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\user\UserInterface;

/**
 * Définit l'entité de soumission de parcours.
 *
 * @ingroup parcours_soumissions_entity
 *
 * @ContentEntityType(
 *   id = "parcours_soumissions_entity",
 *   label = @Translation("Entité de soumission de parcours"),
 *   base_table = "parcours_soumissions_entity",
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\parcours_soumissions\ParcoursSoumissionsEntityListBuilder",
 *   },
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "name",
 *     "firstname" = "firstname",
 *     "name" = "name",
 *     "creation_date",
 *     "updated_date",
 *     "saved_data"
 *   },
 * )
 */
class ParcoursSoumissionsEntity extends ContentEntityBase implements ParcoursSoumissionsEntityInterface {

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type): array {
    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['name'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Nom'))
      ->setDescription(t('Le nom de l\'entité de soumission de parcours.'))
      ->setSettings([
        'max_length' => 255,
        'text_processing' => 0,
      ])
      ->setDefaultValue('Inconnu')
      ->setDisplayOptions('view', [
        'label' => 'above',
        'type' => 'string',
        'weight' => -4,
      ])
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -4,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['firstname'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Prénom'))
      ->setDescription(t('Le prénom de l\'entité de soumission de parcours.'))
      ->setSettings([
        'max_length' => 200,
        'text_processing' => 0,
      ])
      ->setDefaultValue('Inconnu')
      ->setDisplayOptions('view', [
        'label' => 'above',
        'type' => 'string',
        'weight' => -3,
      ])
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -3,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['creation_date'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Date de création'))
      ->setDescription(t('Date de création de l\'entrée'))
      ->setDisplayOptions('view', [
        'label' => 'above',
        'type' => 'timestamp',
        'weight' => -2,
      ])
      ->setDisplayOptions('form', [
        'type' => 'datetime_timestamp',
        'weight' => -2,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['updated_date'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Date de modification'))
      ->setDescription(t('Date de la modification de l\'entrée'))
      ->setDisplayOptions('view', [
        'label' => 'above',
        'type' => 'timestamp',
        'weight' => -1,
      ])
      ->setDisplayOptions('form', [
        'type' => 'datetime_timestamp',
        'weight' => -1,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['saved_data'] = BaseFieldDefinition::create('json')
      ->setLabel(t('Données enregistrées'))
      ->setDescription(t('Les données enregistrées de l\'entité de soumission de parcours.'))
      ->setSettings([
        'default_value' => '',
      ])
      ->setTranslatable(FALSE)
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'json_default',
        'weight' => -4,
      ])
      ->setDisplayOptions('form', [
        'type' => 'json_textarea',
        'weight' => -4,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);


    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function getName(): string {
    return $this->get('name')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setName(string $name): void {
    $this->set('name', $name);
  }

  /**
   * {@inheritdoc}
   */
  public function getFirstName(): string {
    return $this->get('firstname')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setFirstName(string $firstName): void {
    $this->set('firstname', $firstName);
  }

  /**
   * {@inheritdoc}
   */
  public function getCreationDate(): string {
    // Récupère le timestamp de création et le convertit en format de date lisible
    $timestamp = $this->get('creation_date')->value;
    return \Drupal::service('date.formatter')->format($timestamp, 'custom', 'd-m-Y H:i:s');
  }

  /**
   * {@inheritdoc}
   */
  public function getUpdatedDate(): string {
    // Récupère le timestamp de modification et le convertit en format de date lisible
    $timestamp = $this->get('updated_date')->value;
    return \Drupal::service('date.formatter')->format($timestamp, 'custom', 'd-m-Y H:i:s');
  }

  /**
   * {@inheritdoc}
   */
  public function getSavedData(): string {
    return $this->get('saved_data')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setSavedData(string $data): void {
    $this->set('saved_data', $data)->save();
  }

  /**
   * Sert à définir le propriétaire d'une entité ; càd celui qui la crée.
   * Sert surtout dans un contexte où seul le propriétaire de l'entité peut effectuer des actions dessus.
   */

  public function getOwner() {
    // TODO: Implement getOwner() method.
  }

  public function setOwner(UserInterface $account) {
    // TODO: Implement setOwner() method.
  }

  public function getOwnerId() {
    // TODO: Implement getOwnerId() method.
  }

  public function setOwnerId($uid) {
    // TODO: Implement setOwnerId() method.
  }

}
