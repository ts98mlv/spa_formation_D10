<?php

namespace Drupal\parcours_soumissions\Authentication;

use Drupal\Core\Authentication\AuthenticationProviderInterface;
use Drupal\Core\Session\UserSession;
use Drupal\user\Entity\User;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\HttpException;

/**
 * Authentication provider to validate requests with x-api-key directive in header.
 */
class CustomRestAuthentication implements AuthenticationProviderInterface {

    /**
     * {@inheritdoc}
     */
    public function applies(Request $request): bool {
        /**
         * Buy default the authentication plugin will be triggered on all routes/paths
         * visited by the user. For HTML pages we do not want to this authentictor to
         * execute, but executed maily for REST API reqests.
         * Hence we should allow this authenticator to verify the header value only on those routes/paths
         * when it is present. This functions returns bool (true/false), if true below authenticate function will be
         * executed else 403 Forbidden.
         */
        return $request->headers->has('x-api-key');
    }

    /**
     * {@inheritdoc}
     */
    public function authenticate(Request $request): ?UserSession {
        /**
         * Return user account data if the header value matches.
         */
        if ($request->headers->get('x-api-key') !== 'formation_d10') {
            throw new HttpException(403, 'Specified x-api-key value is incorrect');
            return NULL;
        }
        return new UserSession();
    }

}
